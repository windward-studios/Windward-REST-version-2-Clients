
class VersionNumbers:
    VERSION_STR = "20.2.0.62"

    REST_API_VERSION = "2.1.0"
